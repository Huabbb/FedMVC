# Dataset placement

Datasets are not bundled. Place the existing dataset files as follows:

```
data/
  UCI/
    mfeat-fou
    mfeat-fac
    mfeat-kar
    mfeat-pix
    mfeat-zer
    mfeat-mor
  multiview/
    100Leaves.mat
    OutdoorScene.mat
  extra/
    Scene-15.mat
```

MAT files must contain the existing cell array `X` and one label field from `y`, `Y`, `gnd`, `gt`, `label`, `labels`. Views are converted to samples-by-features and standardized by the existing loader. UCI labels assume the original digit-wise ordering (200 samples per digit).
