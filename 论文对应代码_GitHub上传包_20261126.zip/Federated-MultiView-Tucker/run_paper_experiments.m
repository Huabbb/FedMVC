%% run_paper_experiments.m
% Selected existing experiment script; path/entry/output changes only.
% Historical parameters are preserved, not certified table-reproduction settings.
% Fresh MATLAB rerun for two ablation studies of the adaptive hypergraph-weight model.
% Core algorithm logic is copied from the current experiment wrapper; this file only
% changes experiment entry, parameter selection, logging, and result export.
%
% Variants:
%   Ours           : full adaptive hypergraph-weight model
%   Ours_H         : w/o hypergraph regularization, lambda = 0
%   Ours_E         : w/o entropy regularization, tau ~= 0

clear; clc; close all;

repoDir = fileparts(mfilename('fullpath'));
outDir = fullfile(repoDir, 'results', 'paper_experiments');
resultDir = outDir;
if ~exist(resultDir, 'dir'), mkdir(resultDir); end
uciDir = fullfile(repoDir, 'data', 'UCI');
matDir = fullfile(repoDir, 'data', 'multiview');
extraDir = fullfile(repoDir, 'data', 'extra');
assert(exist('kmeans', 'file') == 2, 'Statistics and Machine Learning Toolbox is required.');
assert(exist('matchpairs', 'file') == 2, 'matchpairs is required for exact ACC label assignment.');

datasets = {'UCI', 'Leaves100', 'Scene-15', 'OutdoorScene'};
variants = {'Ours'}; % For ablations use {'Ours', 'Ours_H', 'Ours_E'}.
variantLabels = containers.Map({'Ours','Ours_H','Ours_E'}, {'Ours','w/o Hypergraph','w/o Entropy'});
seeds = 2026082901:2026082905;
repeatTimes = numel(seeds);

rawCsv = fullfile(resultDir, 'experiment_raw.csv');
if exist(rawCsv, 'file')
    rawRows = readtable(rawCsv, 'TextType', 'string');
else
    rawRows = table();
end
allResults = struct();

fprintf('Fresh ablation rerun started at %s\n', string(datetime('now')));
fprintf('Datasets: %s\n', strjoin(datasets, ', '));
fprintf('Variants: %s\n', strjoin(variants, ', '));
fprintf('Seeds: %s\n\n', mat2str(seeds));

for d = 1:numel(datasets)
    datasetChoice = datasets{d};
    [X, gnd, datasetName] = loadSensitivityDataset(datasetChoice, uciDir, matDir, extraDir);
    [~,~,gnd] = unique(gnd(:));
    gnd = gnd(:);
    n = length(gnd);
    for v = 1:numel(X)
        X{v} = double(full(X{v}));
        if size(X{v},1) ~= n && size(X{v},2) == n
            X{v} = X{v}';
        end
        if size(X{v},1) ~= n
            error('View %d has incompatible sample number: [%d,%d], n=%d.', v, size(X{v},1), size(X{v},2), n);
        end
        X{v} = zscoreSafe(X{v});
    end

    for iv = 1:numel(variants)
        variantName = variants{iv};
        fprintf('\n========== %s | %s ==========%s', datasetName, variantName, newline);
        for ir = 1:repeatTimes
            seedVal = seeds(ir);
            if ~isempty(rawRows) && all(ismember({'Dataset','Variant','Seed'}, rawRows.Properties.VariableNames))
                alreadyDone = any(rawRows.Dataset == string(datasetName) & rawRows.Variant == string(variantName) & rawRows.Seed == seedVal);
                if alreadyDone
                    fprintf('Skip existing %s | %s | seed=%d%s', datasetName, variantName, seedVal, newline);
                    continue;
                end
            end
            params = getPaperAblationParams(datasetName, X, gnd);
            params = applyAblationVariant(params, variantName);
            validateParams(X, gnd, params);

            rng(seedVal);
            status = "ok";
            errMsg = "";
            ACC = NaN; NMI = NaN; ARI = NaN; Purity = NaN; elapsed = NaN; finalIter = NaN;
            objDecrease = false;
            try
                tStart = tic;
                [model, result] = runFederatedTuckerMVC(X, params, gnd); %#ok<ASGLU>
                elapsed = toc(tStart);
                ACC = result.metrics.ACC;
                NMI = result.metrics.NMI;
                ARI = result.metrics.ARI;
                Purity = result.metrics.Purity;
                finalIter = numel(result.obj);
                finiteObj = result.obj(isfinite(result.obj));
                if numel(finiteObj) >= 2
                    objDecrease = finiteObj(end) <= finiteObj(1);
                end
                matFile = fullfile(resultDir, sprintf('%s_%s_seed%d_experiment.mat', datasetName, variantName, seedVal));
                save(matFile, 'datasetName', 'variantName', 'seedVal', 'params', 'result', 'ACC', 'NMI', 'ARI', 'Purity', 'elapsed', 'finalIter', 'objDecrease');
            catch ME
                status = "error";
                errMsg = string(ME.message);
                fprintf('ERROR %s | %s | seed=%d: %s\n', datasetName, variantName, seedVal, ME.message);
            end

            newRow = table(string(datasetName), string(variantName), string(variantLabels(variantName)), ir, seedVal, numel(X), params.k, params.lambda, params.tau, params.K, params.r, params.c, params.q, params.s, string(params.initU), string(params.alphaMode), ACC, NMI, ARI, Purity, elapsed, finalIter, objDecrease, status, errMsg, ...
                'VariableNames', {'Dataset','Variant','VariantLabel','Run','Seed','P','ClassNum','lambda','tau','K','r','c','q','s','initU','alphaMode','ACC','NMI','ARI','Purity','Time','FinalIter','ObjDecreased','Status','ErrorMessage'});
            rawRows = [rawRows; newRow]; %#ok<AGROW>
            writetable(rawRows, rawCsv);

            fprintf('%s | %s | seed=%d | ACC=%.4f NMI=%.4f ARI=%.4f Purity=%.4f Time=%.2fs | %s\n', ...
                datasetName, variantName, seedVal, ACC, NMI, ARI, Purity, elapsed, status);
        end
    end
end

summaryT = summarizeAblation(rawRows);
writetable(summaryT, fullfile(resultDir, 'experiment_summary.csv'));
writeAblationMarkdown(summaryT, fullfile(resultDir, 'experiment_summary_bold.md'));
save(fullfile(resultDir, 'experiment_results.mat'), 'rawRows', 'summaryT', 'allResults');

fprintf('\nFresh ablation rerun finished at %s\n', string(datetime('now')));
fprintf('Result directory: %s\n', resultDir);

function params = getPaperAblationParams(datasetName, X, gnd)
    k = numel(unique(gnd));
    V = numel(X);
    params.k = k;
    params.beta = 1e-3;
    params.mu = 1e-3;
    params.maxIter = 50;
    params.tol = 0;
    params.verbose = false;
    params.nRepeatKmeans = 20;
    params.initU = 'random';
    params.hypergraphMode = 'binary';
    params.alphaMode = 'adaptive';
    switch lower(datasetName)
        case 'uci'
            params.lambda = 3; params.tau = 1; params.K = 15;
            params.r = 50; params.c = k; params.q = k; params.s = min(V,k);
        case 'leaves100'
            params.lambda = 0.8; params.tau = 10; params.K = 10;
            params.r = 50; params.c = 50; params.q = 50; params.s = min(V,k);
        case 'scene-15'
            params.lambda = 0.5; params.tau = 10; params.K = 15;
            params.r = 50; params.c = 30; params.q = 15; params.s = min(V,k);
        case 'outdoorscene'
            params.lambda = 2; params.tau = 30; params.K = 20;
            params.r = 50; params.c = 16; params.q = 8; params.s = min(V,k);
        case 'mnist-4'
            params.lambda = 0.5; params.tau = 10; params.K = 15;
            params.r = 40; params.c = 8; params.q = 4; params.s = min(V,k);
        otherwise
            params.lambda = 0.5; params.tau = 10; params.K = 15;
            params.r = 50; params.c = min(2*k,50); params.q = min(k,50); params.s = min(V,k);
    end
end

function params = applyAblationVariant(params, variantName)
    switch lower(variantName)
        case 'ours'
            params.alphaMode = 'adaptive';
        case 'ours_h'
            params.lambda = 0;
            params.alphaMode = 'uniform';
        case 'ours_e'
            params.tau = 1e-6;
            params.alphaMode = 'adaptive';
        otherwise
            error('Unknown variantName: %s.', variantName);
    end
end

function summaryT = summarizeAblation(rawT)
    okT = rawT(rawT.Status == "ok", :);
    [G, ds, varName, varLabel, p, cls] = findgroups(okT.Dataset, okT.Variant, okT.VariantLabel, okT.P, okT.ClassNum);
    Runs = splitapply(@numel, okT.ACC, G);
    ACC_mean = splitapply(@mean, okT.ACC, G); ACC_std = splitapply(@std0, okT.ACC, G);
    NMI_mean = splitapply(@mean, okT.NMI, G); NMI_std = splitapply(@std0, okT.NMI, G);
    ARI_mean = splitapply(@mean, okT.ARI, G); ARI_std = splitapply(@std0, okT.ARI, G);
    Purity_mean = splitapply(@mean, okT.Purity, G); Purity_std = splitapply(@std0, okT.Purity, G);
    Time_mean = splitapply(@mean, okT.Time, G); Time_std = splitapply(@std0, okT.Time, G);
    summaryT = table(ds, varName, varLabel, p, cls, Runs, ACC_mean, ACC_std, NMI_mean, NMI_std, ARI_mean, ARI_std, Purity_mean, Purity_std, Time_mean, Time_std, ...
        'VariableNames', {'Dataset','Variant','VariantLabel','P','ClassNum','Runs','ACC_mean','ACC_std','NMI_mean','NMI_std','ARI_mean','ARI_std','Purity_mean','Purity_std','Time_mean','Time_std'});
end

function writeAblationMarkdown(T, mdPath)
    fid = fopen(mdPath, 'w');
    fprintf(fid, '# Experiment results\n\n');
    fprintf(fid, 'Generated from completed runs. These settings are inherited from a historical experiment, not verified as the exact settings for the manuscript tables.\n\n');
    fprintf(fid, '| Dataset | Variant | P | ClassNum | Runs | ACC | NMI | ARI | Purity | Time(s) |\n');
    fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n');
    dsList = unique(T.Dataset, 'stable');
    for d = 1:numel(dsList)
        idx = find(T.Dataset == dsList(d));
        bestACC = max(T.ACC_mean(idx)); bestNMI = max(T.NMI_mean(idx)); bestARI = max(T.ARI_mean(idx)); bestPur = max(T.Purity_mean(idx));
        for ii = idx'
            acc = formatMetric(T.ACC_mean(ii), T.ACC_std(ii), T.ACC_mean(ii) == bestACC);
            nmi = formatMetric(T.NMI_mean(ii), T.NMI_std(ii), T.NMI_mean(ii) == bestNMI);
            ari = formatMetric(T.ARI_mean(ii), T.ARI_std(ii), T.ARI_mean(ii) == bestARI);
            pur = formatMetric(T.Purity_mean(ii), T.Purity_std(ii), T.Purity_mean(ii) == bestPur);
            fprintf(fid, '| %s | %s | %d | %d | %d | %s | %s | %s | %s | %.2f +/- %.2f |\n', ...
                T.Dataset(ii), T.VariantLabel(ii), T.P(ii), T.ClassNum(ii), T.Runs(ii), acc, nmi, ari, pur, T.Time_mean(ii), T.Time_std(ii));
        end
    end
    fprintf(fid, '\n说明：`w/o Hypergraph` 表示令 lambda=0，并固定 alpha_v=1/V；`w/o Entropy` 表示保留自适应超图权重但令 tau=1e-6 近似移除熵正则项。\n');
    fclose(fid);
end

function txt = formatMetric(mu, sd, isBest)
    txt = sprintf('%.4f +/- %.4f', mu, sd);
    if isBest
        txt = ['**', txt, '**'];
    end
end

function [X, gnd, datasetName] = loadSensitivityDataset(datasetChoice, uciDir, matDir, extraDir)
    switch lower(datasetChoice)
        case 'uci'
            datasetName = 'UCI';
            X = cell(6,1);
            X{1} = readmatrix(fullfile(uciDir, 'mfeat-fou'), 'FileType', 'text');
            X{2} = readmatrix(fullfile(uciDir, 'mfeat-fac'), 'FileType', 'text');
            X{3} = readmatrix(fullfile(uciDir, 'mfeat-kar'), 'FileType', 'text');
            X{4} = readmatrix(fullfile(uciDir, 'mfeat-pix'), 'FileType', 'text');
            X{5} = readmatrix(fullfile(uciDir, 'mfeat-zer'), 'FileType', 'text');
            X{6} = readmatrix(fullfile(uciDir, 'mfeat-mor'), 'FileType', 'text');
            gnd = repelem((1:10)', 200);
        case 'leaves100'
            datasetName = 'Leaves100';
            S = load(fullfile(matDir, '100Leaves.mat'));
            X = S.X; gnd = getSensitivityLabel(S);
        case {'scene-15','scene15'}
            datasetName = 'Scene-15';
            S = load(fullfile(extraDir, 'Scene-15.mat'));
            X = S.X; gnd = getSensitivityLabel(S);
        case 'outdoorscene'
            datasetName = 'OutdoorScene';
            S = load(fullfile(matDir, 'OutdoorScene.mat'));
            X = S.X; gnd = getSensitivityLabel(S);
        case {'mnist-4','mnist4'}
            datasetName = 'MNIST-4';
            S = load(fullfile(matDir, 'MNIST-4.mat'));
            X = S.X; gnd = getSensitivityLabel(S);
        otherwise
            error('Unknown dataset: %s', datasetChoice);
    end
end

function gnd = getSensitivityLabel(S)
    if isfield(S,'y'), gnd = S.y(:);
    elseif isfield(S,'Y'), gnd = S.Y(:);
    elseif isfield(S,'gnd'), gnd = S.gnd(:);
    elseif isfield(S,'gt'), gnd = S.gt(:);
    elseif isfield(S,'label'), gnd = S.label(:);
    elseif isfield(S,'labels'), gnd = S.labels(:);
    else, error('No label field found.');
    end
end

function s = std0(x)
    if numel(x) <= 1, s = 0; else, s = std(x); end
end

function validateParams(X, gnd, params)

    n = length(gnd);
    totalDim = 0;
    for v = 1:numel(X)
        totalDim = totalDim + size(X{v}, 2);
    end

    if params.q > params.r
        error('Dimension error: params.q = %d must be <= params.r = %d.', params.q, params.r);
    end

    if params.s > numel(X)
        error('Dimension error: params.s = %d must be <= number of views = %d.', params.s, numel(X));
    end

    if strcmpi(params.initU, 'svd')
        maxC = min(n, totalDim);
        if params.c > maxC
            error(['Dimension error for SVD initialization: params.c = %d, but min(n,totalDim) = %d.\n' ...
                   'Please reduce params.c, for example use params.c = 50 for Leaves100.'], ...
                   params.c, maxC);
        end
    end

    if params.c <= 0 || params.r <= 0 || params.q <= 0 || params.s <= 0
        error('Dimension parameters r, c, q, s must be positive.');
    end
end

%% ========================================================================
%                            主算法函数
% ========================================================================

function [model, result] = runFederatedTuckerMVC(X, params, gnd)

    if nargin < 3
        gnd = [];
    end

    V = numel(X);
    n = size(X{1}, 1);

    for v = 1:V
        if size(X{v}, 1) ~= n
            error('All views must have the same number of samples.');
        end
    end

    k = params.k;
    r = params.r;
    c = params.c;
    q = params.q;
    s = params.s;

    lambda = params.lambda;
    tau = params.tau;
    beta = params.beta;
    mu = params.mu;
    K = params.K;

    maxIter = params.maxIter;
    tol = params.tol;

    %% 1. 客户端本地构造超图拉普拉斯矩阵
    Lh = cell(V, 1);
    for v = 1:V
        Lh{v} = buildHypergraphLaplacian(X{v}, K, params.hypergraphMode);
    end

    %% 2. 初始化模型变量
    model = initModel(X, r, c, q, s, params.initU);

    objHist = zeros(maxIter, 1);
    accHist = zeros(maxIter, 1);
    nmiHist = zeros(maxIter, 1);
    ariHist = zeros(maxIter, 1);

    %% 3. 交替优化
    for iter = 1:maxIter

        %% Step 1: 客户端本地更新 W^{(v)}
        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            model.W{v} = updateWLocal(X{v}, model.U, model.A, Mv, beta);
        end

        %% Step 2: 服务器更新共享样本表示 U
        gradU = zeros(n, c);
        lipschitzU = eps;

        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            [gradUv, Lv] = localGradientU( ...
                X{v}, model.W{v}, model.U, model.A, Mv, ...
                Lh{v}, lambda, model.alpha(v));
            gradU = gradU + gradUv;
            lipschitzU = lipschitzU + Lv;
        end

        Utemp = model.U - gradU / lipschitzU;
        model.U = orthQR(Utemp);

        %% Step 3: 服务器更新潜在特征因子 A
        T = zeros(r, q);

        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            Zv = X{v} * model.W{v};
            T = T + Zv' * model.U * Mv;
        end

        model.A = orthProcrustes(T);

        %% Step 4: 服务器更新核心张量 G
        C = zeros(c, q, V);

        for v = 1:V
            Zv = X{v} * model.W{v};
            C(:, :, v) = model.U' * Zv * model.A;
        end

        model.G = updateG(C, model.P, mu);

        %% Step 5: 服务器更新视图因子矩阵 P
        model.P = updateP(C, model.G);

        %% Step 6: 服务器更新自适应视图权重 alpha
        h = zeros(V, 1);
        for v = 1:V
            h(v) = full(trace(model.U' * (Lh{v} * model.U)));
        end

        if strcmpi(params.alphaMode, 'adaptive')
            model.alpha = updateAlpha(h, lambda, tau);
        elseif strcmpi(params.alphaMode, 'uniform')
            model.alpha = ones(V, 1) / V;
        else
            error('Unknown alphaMode: %s.', params.alphaMode);
        end

        %% Step 7: 计算目标函数
        objHist(iter) = computeObjective(X, Lh, model, lambda, tau, beta, mu);

        %% Step 8: 当前 U 上做聚类并记录指标
        if ~isempty(gnd)
            Ucluster = rowNormalize(model.U);
            pred = kmeans(Ucluster, k, ...
                'Replicates', params.nRepeatKmeans, ...
                'MaxIter', 1000, ...
                'Display', 'off');

            metricsNow = clusteringMetrics(gnd, pred);
            accHist(iter) = metricsNow.ACC;
            nmiHist(iter) = metricsNow.NMI;
            ariHist(iter) = metricsNow.ARI;
        end

        %% Step 9: 打印迭代信息
        if params.verbose
            if ~isempty(gnd)
                fprintf('Iter %03d | Obj = %.6e | ACC = %.4f | NMI = %.4f | ARI = %.4f | alpha = ', ...
                    iter, objHist(iter), accHist(iter), nmiHist(iter), ariHist(iter));
                fprintf('%.3f ', model.alpha);
                fprintf('\n');
            else
                fprintf('Iter %03d | Obj = %.6e\n', iter, objHist(iter));
            end
        end

        %% Step 10: 收敛判断
        if iter > 1 && tol > 0
            relChange = abs(objHist(iter) - objHist(iter - 1)) / ...
                max(1, abs(objHist(iter - 1)));

            if relChange < tol
                objHist = objHist(1:iter);
                accHist = accHist(1:iter);
                nmiHist = nmiHist(1:iter);
                ariHist = ariHist(1:iter);
                break;
            end
        end
    end

    %% 4. 最终聚类
    Ucluster = rowNormalize(model.U);
    pred = kmeans(Ucluster, k, ...
        'Replicates', params.nRepeatKmeans, ...
        'MaxIter', 1000, ...
        'Display', 'off');

    if ~isempty(gnd)
        finalMetrics = clusteringMetrics(gnd, pred);
    else
        finalMetrics = struct();
    end

    result.pred = pred;
    result.obj = objHist;
    result.accHist = accHist;
    result.nmiHist = nmiHist;
    result.ariHist = ariHist;
    result.metrics = finalMetrics;
    result.Lh = Lh;
end

%% ========================================================================
%                            模型初始化
% ========================================================================

function model = initModel(X, r, c, q, s, initU)

    V = numel(X);
    n = size(X{1}, 1);

    model.W = cell(V, 1);

    for v = 1:V
        dv = size(X{v}, 2);
        model.W{v} = randn(dv, r);
    end

    if strcmpi(initU, 'svd')
        Xcat = [];
        for vv = 1:V
            Xcat = [Xcat, X{vv}];
        end

        if c < min(size(Xcat))
            [U0, ~, ~] = svds(Xcat, c);
        else
            [Ufull, ~, ~] = svd(Xcat, 'econ');
            U0 = Ufull(:, 1:c);
        end

        model.U = orthQR(U0);
    elseif strcmpi(initU, 'random')
        model.U = orthQR(randn(n, c));
    else
        error('Unknown initU: %s.', initU);
    end

    model.A = orthQR(randn(r, q));
    model.P = orthQR(randn(V, s));
    model.G = randn(c, q, s);
    model.alpha = ones(V, 1) / V;
end

%% ========================================================================
%                            变量更新
% ========================================================================

function Wv = updateWLocal(Xv, U, A, Mv, beta)

    dv = size(Xv, 2);

    leftMat = Xv' * Xv + beta * eye(dv);
    rightMat = Xv' * U * Mv * A';

    Wv = leftMat \ rightMat;
end


function [gradUv, Lv] = localGradientU(Xv, Wv, U, A, Mv, Lhv, lambda, alphaV)

    Zv = Xv * Wv;

    Bv = Mv * (A' * A) * Mv';

    gradRec = 2 * (U * Bv - Zv * A * Mv');
    gradHyper = 2 * lambda * alphaV * (Lhv * U);

    gradUv = gradRec + gradHyper;

    LvRec = 2 * norm(Bv, 2);

    try
        normL = normest(Lhv);
    catch
        normL = norm(full(Lhv), 2);
    end

    LvHyper = 2 * lambda * alphaV * normL;
    Lv = LvRec + LvHyper + eps;
end


function A = orthProcrustes(T)
    [Phi, ~, Psi] = svd(T, 'econ');
    A = Phi * Psi';
end


function G = updateG(C, P, mu)

    [c, q, ~] = size(C);
    s = size(P, 2);

    C3 = mode3Unfold(C);              % V × (c q)
    G3 = (P' * P + mu * eye(s)) \ (P' * C3);

    G = mode3Fold(G3, c, q, s);
end


function P = updateP(C, G)

    C3 = mode3Unfold(C);              % V × (c q)
    G3 = mode3Unfold(G);              % s × (c q)

    B = C3 * G3';                     % V × s

    [Phi, ~, Psi] = svd(B, 'econ');
    P = Phi * Psi';
end


function alpha = updateAlpha(h, lambda, tau)

    if tau <= 0
        error('tau must be positive. Use tau = 1e-6 for entropy ablation.');
    end

    score = -lambda * h / tau;
    score = score - max(score);

    alpha = exp(score);
    alpha = alpha / sum(alpha);
end


function obj = computeObjective(X, Lh, model, lambda, tau, beta, mu)

    V = numel(X);

    recTerm = 0;
    hyperTerm = 0;
    WTerm = 0;

    for v = 1:V
        Mv = mode3ProductView(model.G, model.P(v, :));

        Zv = X{v} * model.W{v};
        Recv = model.U * Mv * model.A';

        E = Zv - Recv;

        recTerm = recTerm + sum(E(:).^2);

        hv = full(trace(model.U' * (Lh{v} * model.U)));
        hyperTerm = hyperTerm + model.alpha(v) * hv;

        WTerm = WTerm + sum(model.W{v}(:).^2);
    end

    entropyTerm = sum(model.alpha .* log(max(model.alpha, eps)));
    GTerm = sum(model.G(:).^2);

    obj = recTerm ...
        + lambda * hyperTerm ...
        + tau * entropyTerm ...
        + beta * WTerm ...
        + mu * GTerm;
end

%% ========================================================================
%                            超图拉普拉斯矩阵
% ========================================================================

function L = buildHypergraphLaplacian(X, K, mode)

    n = size(X, 1);
    K = min(K, n - 1);

    x2 = sum(X.^2, 2);
    dist2 = x2 + x2' - 2 * (X * X');
    dist2(dist2 < 0) = 0;

    [sortedDist2, idx] = sort(dist2, 2, 'ascend');

    neighborIdx = idx(:, 1:K + 1);

    numEdges = n;
    numIncidence = n * (K + 1);

    rows = zeros(numIncidence, 1);
    cols = zeros(numIncidence, 1);
    vals = zeros(numIncidence, 1);

    cnt = 0;

    for i = 1:n
        ids = neighborIdx(i, :)';
        len = numel(ids);

        rows(cnt + 1:cnt + len) = ids;
        cols(cnt + 1:cnt + len) = i;

        if strcmpi(mode, 'binary')
            localWeight = ones(len, 1);
        elseif strcmpi(mode, 'weighted')
            sigma2 = sortedDist2(i, K + 1);
            if sigma2 < eps
                sigma2 = mean(sortedDist2(i, 2:K + 1)) + eps;
            end
            localDist2 = dist2(i, ids);
            localWeight = exp(-localDist2(:) ./ (2 * sigma2 + eps));
            localWeight(ids == i) = 1;
        else
            error('Unknown hypergraphMode: %s. Use binary or weighted.', mode);
        end

        vals(cnt + 1:cnt + len) = localWeight;
        cnt = cnt + len;
    end

    H = sparse(rows, cols, vals, n, numEdges);

    w = ones(numEdges, 1);

    dv = H * w;
    de = sum(H, 1)';

    dv(dv == 0) = eps;
    de(de == 0) = eps;

    DvInvSqrt = spdiags(1 ./ sqrt(dv), 0, n, n);
    WeDeInv = spdiags(w ./ de, 0, numEdges, numEdges);

    Theta = DvInvSqrt * H * WeDeInv * H' * DvInvSqrt;

    L = speye(n) - Theta;
    L = (L + L') / 2;
end

%% ========================================================================
%                            Tucker 工具函数
% ========================================================================

function Mv = mode3ProductView(G, pv)

    [c, q, s] = size(G);
    Mv = zeros(c, q);

    for t = 1:s
        Mv = Mv + G(:, :, t) * pv(t);
    end
end


function X3 = mode3Unfold(X)
    X3 = reshape(permute(X, [3, 1, 2]), size(X, 3), []);
end


function X = mode3Fold(X3, I, J, K)
    X = permute(reshape(X3, K, I, J), [2, 3, 1]);
end

%% ========================================================================
%                            基础工具函数
% ========================================================================

function Q = orthQR(X)

    [Q, R] = qr(X, 0);

    d = sign(diag(R));
    d(d == 0) = 1;

    Q = Q * diag(d);
end


function Y = rowNormalize(X)
    rowNorm = sqrt(sum(X.^2, 2));
    rowNorm(rowNorm < eps) = 1;
    Y = X ./ rowNorm;
end


function X = zscoreSafe(X)

    mu = mean(X, 1);
    sigma = std(X, 0, 1);

    sigma(sigma < eps) = 1;

    X = (X - mu) ./ sigma;
end

%% ========================================================================
%                            聚类评价指标
% ========================================================================

function metrics = clusteringMetrics(gnd, pred)

    gnd = gnd(:);
    pred = pred(:);

    [~, ~, gndId] = unique(gnd);
    [~, ~, predId] = unique(pred);

    numPred = max(predId);
    numTrue = max(gndId);

    Cont = accumarray([predId, gndId], 1, [numPred, numTrue]);

    metrics.ACC = clusteringACC(Cont);
    metrics.NMI = clusteringNMI(Cont);
    metrics.ARI = clusteringARI(Cont);
    metrics.Purity = clusteringPurity(Cont);
end


function acc = clusteringACC(Cont)

    K = max(size(Cont));
    W = zeros(K, K);
    W(1:size(Cont, 1), 1:size(Cont, 2)) = Cont;

    if exist('matchpairs', 'file') == 2
        cost = max(W(:)) - W;
        pairs = matchpairs(cost, max(cost(:)) + 1);

        val = 0;
        for i = 1:size(pairs, 1)
            val = val + W(pairs(i, 1), pairs(i, 2));
        end
    else
        warning('matchpairs not found. Using greedy assignment fallback.');
        val = greedyAssignment(W);
    end

    acc = val / sum(W(:));
end


function val = greedyAssignment(W)

    val = 0;
    Wtmp = W;

    while true
        [m, ind] = max(Wtmp(:));

        if m <= 0
            break;
        end

        [i, j] = ind2sub(size(Wtmp), ind);

        val = val + Wtmp(i, j);

        Wtmp(i, :) = -inf;
        Wtmp(:, j) = -inf;
    end
end


function nmi = clusteringNMI(Cont)

    N = sum(Cont(:));

    Pi = sum(Cont, 2);
    Pj = sum(Cont, 1);

    MI = 0;

    for i = 1:size(Cont, 1)
        for j = 1:size(Cont, 2)
            if Cont(i, j) > 0
                MI = MI + Cont(i, j) / N * ...
                    log((Cont(i, j) * N) / (Pi(i) * Pj(j)));
            end
        end
    end

    Hi = -sum((Pi(Pi > 0) / N) .* log(Pi(Pi > 0) / N));
    Hj = -sum((Pj(Pj > 0) / N) .* log(Pj(Pj > 0) / N));

    nmi = 2 * MI / (Hi + Hj + eps);
end


function ari = clusteringARI(Cont)

    comb2 = @(x) x .* (x - 1) / 2;

    N = sum(Cont(:));

    sumNij = sum(comb2(Cont(:)));
    sumAi = sum(comb2(sum(Cont, 2)));
    sumBj = sum(comb2(sum(Cont, 1)));

    total = comb2(N);

    expectedIndex = sumAi * sumBj / total;
    maxIndex = 0.5 * (sumAi + sumBj);

    ari = (sumNij - expectedIndex) / (maxIndex - expectedIndex + eps);
end


function purity = clusteringPurity(Cont)
    purity = sum(max(Cont, [], 2)) / sum(Cont(:));
end




