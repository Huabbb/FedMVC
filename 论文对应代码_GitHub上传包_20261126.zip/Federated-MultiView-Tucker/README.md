# Hypergraph-Regularized Adaptive Federated Multi-view Tucker Clustering

This repository packages selected **existing MATLAB code**, rather than a newly implemented solver. It simulates one client per view in a single MATLAB process.

The model reconstructs mapped views `X{v} * W{v}` with Tucker factors and a shared sample representation, and combines view-wise hypergraph regularization, entropy-regularized structural weights, ridge regularization of local mappings, and core regularization. Updates follow W, U (gradient + QR), A, G, P, alpha.

## Requirements

- MATLAB with Statistics and Machine Learning Toolbox (`kmeans` and `matchpairs`). Code was checked with MATLAB R2024a.
- Existing datasets arranged as described in [data/README.md](data/README.md).
- No external tensor toolbox is required by these selected scripts.

## Run

Open this repository folder in MATLAB and run:

```matlab
run_paper_experiments
```

The default selection runs the full adaptive model on UCI, Leaves100, Scene-15 and OutdoorScene. To run one dataset, edit `datasets` near the top. For the existing ablation variants, set `variants = {'Ours', 'Ours_H', 'Ours_E'}`. Choose a separate output folder when changing settings, since completed dataset/variant/seed records are skipped.

Results (per-run MAT files, raw CSV, summary CSV and Markdown) are written to `results/paper_experiments/`. These outputs are ignored by Git.

`FTMC_Tucker_Complete.m` is the earlier self-contained entry with the original UCI/Leaves100/MSRC-v5 loader. Its original default is Leaves100, 10 repeats and **5 optimization iterations**; it is retained for provenance and is not the recommended four-dataset entry. Its optional figures are written in MATLAB's working directory.

## Preserved historical settings

The four-dataset entry retains 5 seeds (2026082901–2026082905), 50 optimization iterations, 20 K-means replicates, random U initialization, binary hypergraphs and beta = mu = 0.001.

| Dataset | r | c | q | s | lambda | tau | K |
|---|---:|---:|---:|---:|---:|---:|---:|
| UCI | 50 | 10 | 10 | 6 | 3 | 1 | 15 |
| Leaves100 | 50 | 50 | 50 | 3 | 0.8 | 10 | 10 |
| Scene-15 | 50 | 30 | 15 | 3 | 0.5 | 10 | 15 |
| OutdoorScene | 50 | 16 | 8 | 4 | 2 | 30 | 20 |

These are the settings of the selected historical ablation runner. **Exact reproduction of the manuscript tables or 300-iteration plots has not been established.** The algorithm matches the manuscript's model and update structure; that does not establish identity of datasets, parameters, seeds and aggregation protocols for every published number. No performance results are asserted by this package.

The retained `Ours_H` variant sets lambda = 0 and uniform alpha. `Ours_E` uses tau = 1e-6, an approximation to removing entropy regularization. The solver retains its original metric calculations and final K-means rerun. Original comments and local helper names are preserved.

## Selection and provenance

The initially named `修改版本/代码` folder implements a different reconstruction model (`Xv ~= U Bv A' Wv'`). It is excluded. The selected code comes from the adaptive-hypergraph branch; [MANIFEST.csv](MANIFEST.csv) records source paths relative to the local project and SHA-256 digests. [整理说明.md](整理说明.md) explains the selection in Chinese.

Only data paths, output paths/labels and experiment entry selection were adjusted. The numerical solver and its helpers are unchanged from their respective source scripts. Baseline implementations, parameter-search histories, datasets, historical result files, manuscripts and temporary files are not bundled. No license or author details have been invented; add the agreed project license and paper citation when available.
