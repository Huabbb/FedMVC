%% FTMC_Tucker_Complete.m
% 基于 Tucker 分解的联邦多视图聚类完整实验代码
% 单机模拟联邦场景：X{v} 表示第 v 个客户端/视图方的数据
% 最终对共享样本表示 U 的行向量做 K-means 聚类
%
% 主要目标函数：
% sum_v ||Xv*Wv - U*(G x_3 p_v^T)*A'||_F^2
% + lambda * sum_v alpha_v * Tr(U' Lh_v U)
% + tau * sum_v alpha_v log(alpha_v)
% + beta * sum_v ||Wv||_F^2
% + mu * ||G||_F^2

clear;
clc;
close all;

rng(2026);

%% ===================== 0. 实验开关 =====================
% 可选数据集：'UCI', 'Leaves100', 'MSRC_v5'
datasetChoice = 'Leaves100';
 
% 可选实验版本：
% 'Ours'    : 完整模型
% 'Ours_H'  : 去掉超图正则项
% 'Ours_A'  : 去掉自适应视图权重，固定 alpha = 1/V
% 'Ours_E'  : 去掉熵正则项
variantName = 'Ours';

% 正式实验建议 50；调试时可改成 5 或 10
numRuns = 10;

% 数据路径：按你的本机路径修改
repoDir = fileparts(mfilename('fullpath'));
uciDir = fullfile(repoDir, 'data', 'UCI');
matDir = fullfile(repoDir, 'data', 'multiview');

% 是否画图和保存图
drawFigures = false;
saveFigures = false;

%% ===================== 1. 读取数据 =====================
[X, gnd, datasetName] = loadDataset(datasetChoice, uciDir, matDir);

% 标签统一为 1,2,...,k
[~, ~, gnd] = unique(gnd(:));
gnd = gnd(:);

% 数据预处理：确保每个视图是 n × d_v，并做标准化
n = length(gnd);
for v = 1:numel(X)
    X{v} = double(full(X{v}));

    if size(X{v}, 1) ~= n && size(X{v}, 2) == n
        X{v} = X{v}';
    end

    if size(X{v}, 1) ~= n
        error('View %d has incompatible sample number: size = [%d, %d], n = %d.', ...
            v, size(X{v}, 1), size(X{v}, 2), n);
    end

    X{v} = zscoreSafe(X{v});
end

printDatasetInfo(X, gnd, datasetName);

%% ===================== 2. 设置模型参数 =====================
params = getDefaultParams(datasetChoice, X, gnd);
params = applyVariantParams(params, variantName);

% 参数合法性检查
validateParams(X, gnd, params);

fprintf('\n========== Experiment Setting ==========\n');
fprintf('Dataset        : %s\n', datasetName);
fprintf('Variant        : %s\n', variantName);
fprintf('numRuns        : %d\n', numRuns);
fprintf('r, c, q, s     : %d, %d, %d, %d\n', params.r, params.c, params.q, params.s);
fprintf('lambda, tau    : %.4g, %.4g\n', params.lambda, params.tau);
fprintf('beta, mu       : %.4g, %.4g\n', params.beta, params.mu);
fprintf('K              : %d\n', params.K);
fprintf('maxIter        : %d\n', params.maxIter);
fprintf('alphaMode      : %s\n', params.alphaMode);
fprintf('initU          : %s\n', params.initU);
fprintf('hypergraphMode : %s\n', params.hypergraphMode);

%% ===================== 3. 运行模型 =====================
ACC = zeros(numRuns, 1);
NMI = zeros(numRuns, 1);
ARI = zeros(numRuns, 1);
Purity = zeros(numRuns, 1);

accHistAll = nan(params.maxIter, numRuns);
nmiHistAll = nan(params.maxIter, numRuns);
ariHistAll = nan(params.maxIter, numRuns);
objHistAll = nan(params.maxIter, numRuns);

for run = 1:numRuns
    rng(2026 + run);

    [model, result] = runFederatedTuckerMVC(X, params, gnd);

    ACC(run) = result.metrics.ACC;
    NMI(run) = result.metrics.NMI;
    ARI(run) = result.metrics.ARI;
    Purity(run) = result.metrics.Purity;

    lenObj = min(params.maxIter, length(result.obj));
    objHistAll(1:lenObj, run) = result.obj(1:lenObj);

    lenAcc = min(params.maxIter, length(result.accHist));
    accHistAll(1:lenAcc, run) = result.accHist(1:lenAcc);
    nmiHistAll(1:lenAcc, run) = result.nmiHist(1:lenAcc);
    ariHistAll(1:lenAcc, run) = result.ariHist(1:lenAcc);

    fprintf('Run %02d | ACC = %.4f | NMI = %.4f | ARI = %.4f | Purity = %.4f\n', ...
        run, ACC(run), NMI(run), ARI(run), Purity(run));
end

fprintf('\n========== Mean ± Std Results ==========\n');
fprintf('ACC    = %.4f ± %.4f\n', mean(ACC), std(ACC));
fprintf('NMI    = %.4f ± %.4f\n', mean(NMI), std(NMI));
fprintf('ARI    = %.4f ± %.4f\n', mean(ARI), std(ARI));
fprintf('Purity = %.4f ± %.4f\n', mean(Purity), std(Purity));

%% ===================== 4. 保存结果 =====================
resultDir = fullfile(repoDir, 'results', 'legacy');
if ~exist(resultDir, 'dir'), mkdir(resultDir); end
saveFile = fullfile(resultDir, sprintf('%s_%s.mat', datasetName, variantName));
save(saveFile, ...
    'datasetName', 'datasetChoice', 'variantName', 'params', ...
    'ACC', 'NMI', 'ARI', 'Purity', ...
    'accHistAll', 'nmiHistAll', 'ariHistAll', 'objHistAll');

fprintf('\nSaved result file: %s\n', saveFile);

%% ===================== 5. 输出与画图 =====================
disp('========== Last Run Clustering Results ==========');
disp(result.metrics);

if drawFigures
    objMean = mean(objHistAll, 2, 'omitnan');
    accMean = mean(accHistAll, 2, 'omitnan');
    nmiMean = mean(nmiHistAll, 2, 'omitnan');
    iters = 1:params.maxIter;

    figure;
    plot(iters, objMean, '-o', 'LineWidth', 1.5, 'MarkerSize', 4);
    xlabel('Iteration');
    ylabel('Objective Value');
    title(sprintf('Convergence Curve on %s (%s)', datasetName, variantName), 'Interpreter', 'none');
    grid on;
    set(gca, 'FontSize', 12);

    if saveFigures
        exportgraphics(gcf, sprintf('%s_%s_Objective.png', datasetName, variantName), 'Resolution', 300);
        savefig(gcf, sprintf('%s_%s_Objective.fig', datasetName, variantName));
    end

    figure;
    plot(iters, accMean, '-o', 'LineWidth', 1.8, 'MarkerSize', 4);
    xlabel('Iteration');
    ylabel('ACC');
    title(sprintf('Mean ACC Curve on %s (%s)', datasetName, variantName), 'Interpreter', 'none');
    grid on;
    set(gca, 'FontSize', 12);

    if saveFigures
        exportgraphics(gcf, sprintf('%s_%s_ACC.png', datasetName, variantName), 'Resolution', 300);
        savefig(gcf, sprintf('%s_%s_ACC.fig', datasetName, variantName));
    end

    figure;
    plot(iters, nmiMean, '-o', 'LineWidth', 1.8, 'MarkerSize', 4);
    xlabel('Iteration');
    ylabel('NMI');
    title(sprintf('Mean NMI Curve on %s (%s)', datasetName, variantName), 'Interpreter', 'none');
    grid on;
    set(gca, 'FontSize', 12);

    if saveFigures
        exportgraphics(gcf, sprintf('%s_%s_NMI.png', datasetName, variantName), 'Resolution', 300);
        savefig(gcf, sprintf('%s_%s_NMI.fig', datasetName, variantName));
    end
end

%% ========================================================================
%                            数据加载函数
% ========================================================================

function [X, gnd, datasetName] = loadDataset(datasetChoice, uciDir, matDir)

    switch lower(datasetChoice)
        case 'uci'
            datasetName = 'UCI';
            X = cell(6, 1);
            X{1} = readmatrix(fullfile(uciDir, 'mfeat-fou'), 'FileType', 'text');
            X{2} = readmatrix(fullfile(uciDir, 'mfeat-fac'), 'FileType', 'text');
            X{3} = readmatrix(fullfile(uciDir, 'mfeat-kar'), 'FileType', 'text');
            X{4} = readmatrix(fullfile(uciDir, 'mfeat-pix'), 'FileType', 'text');
            X{5} = readmatrix(fullfile(uciDir, 'mfeat-zer'), 'FileType', 'text');
            X{6} = readmatrix(fullfile(uciDir, 'mfeat-mor'), 'FileType', 'text');
            gnd = repelem((1:10)', 200);

        case 'leaves100'
            datasetName = 'Leaves100';
            S = load(fullfile(matDir, '100Leaves.mat'));
            X = S.X;
            gnd = getLabelFromStruct(S);

        case 'msrc_v5'
            datasetName = 'MSRC_v5';
            S = load(fullfile(matDir, 'MSRC-v5.mat'));
            X = S.X;
            gnd = getLabelFromStruct(S);

        otherwise
            error('Unknown datasetChoice: %s. Use UCI, Leaves100, or MSRC_v5.', datasetChoice);
    end
end


function gnd = getLabelFromStruct(S)
    if isfield(S, 'y')
        gnd = S.y(:);
    elseif isfield(S, 'Y')
        gnd = S.Y(:);
    elseif isfield(S, 'gnd')
        gnd = S.gnd(:);
    elseif isfield(S, 'gt')
        gnd = S.gt(:);
    elseif isfield(S, 'label')
        gnd = S.label(:);
    elseif isfield(S, 'labels')
        gnd = S.labels(:);
    else
        error('Cannot find label variable. Expected y, Y, gnd, gt, label, or labels.');
    end
end


function printDatasetInfo(X, gnd, datasetName)
    fprintf('\n========== Dataset Information ==========\n');
    fprintf('Dataset: %s\n', datasetName);
    fprintf('Number of views: %d\n', numel(X));
    fprintf('Number of samples: %d\n', length(gnd));
    fprintf('Number of clusters: %d\n', numel(unique(gnd)));

    for v = 1:numel(X)
        fprintf('View %d: %d samples, %d features\n', ...
            v, size(X{v}, 1), size(X{v}, 2));
    end

    classCount = accumarray(gnd(:), 1);
    fprintf('\n========== Class Distribution ==========\n');
    fprintf('Min class size: %d\n', min(classCount));
    fprintf('Max class size: %d\n', max(classCount));
    fprintf('Max/Min ratio: %.2f\n', max(classCount) / min(classCount));

    if length(classCount) <= 30
        for i = 1:length(classCount)
            fprintf('Class %d: %d samples\n', i, classCount(i));
        end
    else
        fprintf('Class counts omitted because number of classes is %d.\n', length(classCount));
    end
end

%% ========================================================================
%                            参数设置函数
% ========================================================================

function params = getDefaultParams(datasetChoice, X, gnd)

    k = numel(unique(gnd));
    V = numel(X);

    params.k = k;

    % 通用默认值
    params.lambda = 0.1;
    params.tau = 1.0;
    params.beta = 1e-3;
    params.mu = 1e-3;
    params.maxIter = 5;
    params.tol = 0;
    params.verbose = false;
    params.nRepeatKmeans = 50;

    % 初始化与超图构造
    % initU = 'svd' 更稳定；如果要严格随机初始化，可以改成 'random'
    params.initU = 'svd';

    % hypergraphMode = 'binary' 对应论文中 KNN 超图均等关联；
    % hypergraphMode = 'weighted' 使用高斯软关联权重
    params.hypergraphMode = 'binary';

    switch lower(datasetChoice)
        case 'uci'
            params.r = 50;
            params.c = k;
            %params.c = 20;
            params.q = k;
            %params.q = 20;
            params.s = min(V, k);
            params.K = 5;

        case 'leaves100'
            % Leaves100 有 100 类，不建议 c=2k；固定低维表示更稳
            params.r = 50;
            params.c = 50;
            params.q = 50;
            params.s = min(V, k);
            params.K = 5;

        case 'msrc_v5'
            % MSRC 样本较少，r=30, c=2k, K=10 通常更稳
            params.r = 30;
            params.c = 2 * k;
            params.q = k;
            params.s = min(V, k);
            params.K = 10;

        otherwise
            error('Unknown datasetChoice: %s.', datasetChoice);
    end
end


function params = applyVariantParams(params, variantName)
    switch lower(variantName)
        case 'ours'
            params.lambda = 0.1;
            params.tau = 1.0;
            params.alphaMode = 'adaptive';

        case 'ours_h'
            % 去掉超图正则时，alpha 和熵项没有实际意义，固定均匀权重
            params.lambda = 0;
            params.tau = 1e-6;
            params.alphaMode = 'uniform';

        case 'ours_a'
            % 保留超图正则，但去掉自适应权重，固定 alpha = 1/V
            params.lambda = 0.1;
            params.tau = 1.0;
            params.alphaMode = 'uniform';

        case 'ours_e'
            % 去掉熵正则，保留自适应权重
            params.lambda = 0.1;
            params.tau = 1e-6;
            params.alphaMode = 'adaptive';

        otherwise
            error('Unknown variantName: %s. Use Ours, Ours_H, Ours_A, or Ours_E.', variantName);
    end
end


function validateParams(X, gnd, params)

    n = length(gnd);
    totalDim = 0;
    for v = 1:numel(X)
        totalDim = totalDim + size(X{v}, 2);
    end

    if params.q > params.r
        error('Dimension error: params.q = %d must be <= params.r = %d.', params.q, params.r);
    end

    if params.s > numel(X)
        error('Dimension error: params.s = %d must be <= number of views = %d.', params.s, numel(X));
    end

    if strcmpi(params.initU, 'svd')
        maxC = min(n, totalDim);
        if params.c > maxC
            error(['Dimension error for SVD initialization: params.c = %d, but min(n,totalDim) = %d.\n' ...
                   'Please reduce params.c, for example use params.c = 50 for Leaves100.'], ...
                   params.c, maxC);
        end
    end

    if params.c <= 0 || params.r <= 0 || params.q <= 0 || params.s <= 0
        error('Dimension parameters r, c, q, s must be positive.');
    end
end

%% ========================================================================
%                            主算法函数
% ========================================================================

function [model, result] = runFederatedTuckerMVC(X, params, gnd)

    if nargin < 3
        gnd = [];
    end

    V = numel(X);
    n = size(X{1}, 1);

    for v = 1:V
        if size(X{v}, 1) ~= n
            error('All views must have the same number of samples.');
        end
    end

    k = params.k;
    r = params.r;
    c = params.c;
    q = params.q;
    s = params.s;

    lambda = params.lambda;
    tau = params.tau;
    beta = params.beta;
    mu = params.mu;
    K = params.K;

    maxIter = params.maxIter;
    tol = params.tol;

    %% 1. 客户端本地构造超图拉普拉斯矩阵
    Lh = cell(V, 1);
    for v = 1:V
        Lh{v} = buildHypergraphLaplacian(X{v}, K, params.hypergraphMode);
    end

    %% 2. 初始化模型变量
    model = initModel(X, r, c, q, s, params.initU);

    objHist = zeros(maxIter, 1);
    accHist = zeros(maxIter, 1);
    nmiHist = zeros(maxIter, 1);
    ariHist = zeros(maxIter, 1);

    %% 3. 交替优化
    for iter = 1:maxIter

        %% Step 1: 客户端本地更新 W^{(v)}
        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            model.W{v} = updateWLocal(X{v}, model.U, model.A, Mv, beta);
        end

        %% Step 2: 服务器更新共享样本表示 U
        gradU = zeros(n, c);
        lipschitzU = eps;

        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            [gradUv, Lv] = localGradientU( ...
                X{v}, model.W{v}, model.U, model.A, Mv, ...
                Lh{v}, lambda, model.alpha(v));
            gradU = gradU + gradUv;
            lipschitzU = lipschitzU + Lv;
        end

        Utemp = model.U - gradU / lipschitzU;
        model.U = orthQR(Utemp);

        %% Step 3: 服务器更新潜在特征因子 A
        T = zeros(r, q);

        for v = 1:V
            Mv = mode3ProductView(model.G, model.P(v, :));
            Zv = X{v} * model.W{v};
            T = T + Zv' * model.U * Mv;
        end

        model.A = orthProcrustes(T);

        %% Step 4: 服务器更新核心张量 G
        C = zeros(c, q, V);

        for v = 1:V
            Zv = X{v} * model.W{v};
            C(:, :, v) = model.U' * Zv * model.A;
        end

        model.G = updateG(C, model.P, mu);

        %% Step 5: 服务器更新视图因子矩阵 P
        model.P = updateP(C, model.G);

        %% Step 6: 服务器更新自适应视图权重 alpha
        h = zeros(V, 1);
        for v = 1:V
            h(v) = full(trace(model.U' * (Lh{v} * model.U)));
        end

        if strcmpi(params.alphaMode, 'adaptive')
            model.alpha = updateAlpha(h, lambda, tau);
        elseif strcmpi(params.alphaMode, 'uniform')
            model.alpha = ones(V, 1) / V;
        else
            error('Unknown alphaMode: %s.', params.alphaMode);
        end

        %% Step 7: 计算目标函数
        objHist(iter) = computeObjective(X, Lh, model, lambda, tau, beta, mu);

        %% Step 8: 当前 U 上做聚类并记录指标
        if ~isempty(gnd)
            Ucluster = rowNormalize(model.U);
            pred = kmeans(Ucluster, k, ...
                'Replicates', params.nRepeatKmeans, ...
                'MaxIter', 1000, ...
                'Display', 'off');

            metricsNow = clusteringMetrics(gnd, pred);
            accHist(iter) = metricsNow.ACC;
            nmiHist(iter) = metricsNow.NMI;
            ariHist(iter) = metricsNow.ARI;
        end

        %% Step 9: 打印迭代信息
        if params.verbose
            if ~isempty(gnd)
                fprintf('Iter %03d | Obj = %.6e | ACC = %.4f | NMI = %.4f | ARI = %.4f | alpha = ', ...
                    iter, objHist(iter), accHist(iter), nmiHist(iter), ariHist(iter));
                fprintf('%.3f ', model.alpha);
                fprintf('\n');
            else
                fprintf('Iter %03d | Obj = %.6e\n', iter, objHist(iter));
            end
        end

        %% Step 10: 收敛判断
        if iter > 1 && tol > 0
            relChange = abs(objHist(iter) - objHist(iter - 1)) / ...
                max(1, abs(objHist(iter - 1)));

            if relChange < tol
                objHist = objHist(1:iter);
                accHist = accHist(1:iter);
                nmiHist = nmiHist(1:iter);
                ariHist = ariHist(1:iter);
                break;
            end
        end
    end

    %% 4. 最终聚类
    Ucluster = rowNormalize(model.U);
    pred = kmeans(Ucluster, k, ...
        'Replicates', params.nRepeatKmeans, ...
        'MaxIter', 1000, ...
        'Display', 'off');

    if ~isempty(gnd)
        finalMetrics = clusteringMetrics(gnd, pred);
    else
        finalMetrics = struct();
    end

    result.pred = pred;
    result.obj = objHist;
    result.accHist = accHist;
    result.nmiHist = nmiHist;
    result.ariHist = ariHist;
    result.metrics = finalMetrics;
    result.Lh = Lh;
end

%% ========================================================================
%                            模型初始化
% ========================================================================

function model = initModel(X, r, c, q, s, initU)

    V = numel(X);
    n = size(X{1}, 1);

    model.W = cell(V, 1);

    for v = 1:V
        dv = size(X{v}, 2);
        model.W{v} = randn(dv, r);
    end

    if strcmpi(initU, 'svd')
        Xcat = [];
        for vv = 1:V
            Xcat = [Xcat, X{vv}];
        end

        if c < min(size(Xcat))
            [U0, ~, ~] = svds(Xcat, c);
        else
            [Ufull, ~, ~] = svd(Xcat, 'econ');
            U0 = Ufull(:, 1:c);
        end

        model.U = orthQR(U0);
    elseif strcmpi(initU, 'random')
        model.U = orthQR(randn(n, c));
    else
        error('Unknown initU: %s.', initU);
    end

    model.A = orthQR(randn(r, q));
    model.P = orthQR(randn(V, s));
    model.G = randn(c, q, s);
    model.alpha = ones(V, 1) / V;
end

%% ========================================================================
%                            变量更新
% ========================================================================

function Wv = updateWLocal(Xv, U, A, Mv, beta)

    dv = size(Xv, 2);

    leftMat = Xv' * Xv + beta * eye(dv);
    rightMat = Xv' * U * Mv * A';

    Wv = leftMat \ rightMat;
end


function [gradUv, Lv] = localGradientU(Xv, Wv, U, A, Mv, Lhv, lambda, alphaV)

    Zv = Xv * Wv;

    Bv = Mv * (A' * A) * Mv';

    gradRec = 2 * (U * Bv - Zv * A * Mv');
    gradHyper = 2 * lambda * alphaV * (Lhv * U);

    gradUv = gradRec + gradHyper;

    LvRec = 2 * norm(Bv, 2);

    try
        normL = normest(Lhv);
    catch
        normL = norm(full(Lhv), 2);
    end

    LvHyper = 2 * lambda * alphaV * normL;
    Lv = LvRec + LvHyper + eps;
end


function A = orthProcrustes(T)
    [Phi, ~, Psi] = svd(T, 'econ');
    A = Phi * Psi';
end


function G = updateG(C, P, mu)

    [c, q, ~] = size(C);
    s = size(P, 2);

    C3 = mode3Unfold(C);              % V × (c q)
    G3 = (P' * P + mu * eye(s)) \ (P' * C3);

    G = mode3Fold(G3, c, q, s);
end


function P = updateP(C, G)

    C3 = mode3Unfold(C);              % V × (c q)
    G3 = mode3Unfold(G);              % s × (c q)

    B = C3 * G3';                     % V × s

    [Phi, ~, Psi] = svd(B, 'econ');
    P = Phi * Psi';
end


function alpha = updateAlpha(h, lambda, tau)

    if tau <= 0
        error('tau must be positive. Use tau = 1e-6 for entropy ablation.');
    end

    score = -lambda * h / tau;
    score = score - max(score);

    alpha = exp(score);
    alpha = alpha / sum(alpha);
end


function obj = computeObjective(X, Lh, model, lambda, tau, beta, mu)

    V = numel(X);

    recTerm = 0;
    hyperTerm = 0;
    WTerm = 0;

    for v = 1:V
        Mv = mode3ProductView(model.G, model.P(v, :));

        Zv = X{v} * model.W{v};
        Recv = model.U * Mv * model.A';

        E = Zv - Recv;

        recTerm = recTerm + sum(E(:).^2);

        hv = full(trace(model.U' * (Lh{v} * model.U)));
        hyperTerm = hyperTerm + model.alpha(v) * hv;

        WTerm = WTerm + sum(model.W{v}(:).^2);
    end

    entropyTerm = sum(model.alpha .* log(max(model.alpha, eps)));
    GTerm = sum(model.G(:).^2);

    obj = recTerm ...
        + lambda * hyperTerm ...
        + tau * entropyTerm ...
        + beta * WTerm ...
        + mu * GTerm;
end

%% ========================================================================
%                            超图拉普拉斯矩阵
% ========================================================================

function L = buildHypergraphLaplacian(X, K, mode)

    n = size(X, 1);
    K = min(K, n - 1);

    x2 = sum(X.^2, 2);
    dist2 = x2 + x2' - 2 * (X * X');
    dist2(dist2 < 0) = 0;

    [sortedDist2, idx] = sort(dist2, 2, 'ascend');

    neighborIdx = idx(:, 1:K + 1);

    numEdges = n;
    numIncidence = n * (K + 1);

    rows = zeros(numIncidence, 1);
    cols = zeros(numIncidence, 1);
    vals = zeros(numIncidence, 1);

    cnt = 0;

    for i = 1:n
        ids = neighborIdx(i, :)';
        len = numel(ids);

        rows(cnt + 1:cnt + len) = ids;
        cols(cnt + 1:cnt + len) = i;

        if strcmpi(mode, 'binary')
            localWeight = ones(len, 1);
        elseif strcmpi(mode, 'weighted')
            sigma2 = sortedDist2(i, K + 1);
            if sigma2 < eps
                sigma2 = mean(sortedDist2(i, 2:K + 1)) + eps;
            end
            localDist2 = dist2(i, ids);
            localWeight = exp(-localDist2(:) ./ (2 * sigma2 + eps));
            localWeight(ids == i) = 1;
        else
            error('Unknown hypergraphMode: %s. Use binary or weighted.', mode);
        end

        vals(cnt + 1:cnt + len) = localWeight;
        cnt = cnt + len;
    end

    H = sparse(rows, cols, vals, n, numEdges);

    w = ones(numEdges, 1);

    dv = H * w;
    de = sum(H, 1)';

    dv(dv == 0) = eps;
    de(de == 0) = eps;

    DvInvSqrt = spdiags(1 ./ sqrt(dv), 0, n, n);
    WeDeInv = spdiags(w ./ de, 0, numEdges, numEdges);

    Theta = DvInvSqrt * H * WeDeInv * H' * DvInvSqrt;

    L = speye(n) - Theta;
    L = (L + L') / 2;
end

%% ========================================================================
%                            Tucker 工具函数
% ========================================================================

function Mv = mode3ProductView(G, pv)

    [c, q, s] = size(G);
    Mv = zeros(c, q);

    for t = 1:s
        Mv = Mv + G(:, :, t) * pv(t);
    end
end


function X3 = mode3Unfold(X)
    X3 = reshape(permute(X, [3, 1, 2]), size(X, 3), []);
end


function X = mode3Fold(X3, I, J, K)
    X = permute(reshape(X3, K, I, J), [2, 3, 1]);
end

%% ========================================================================
%                            基础工具函数
% ========================================================================

function Q = orthQR(X)

    [Q, R] = qr(X, 0);

    d = sign(diag(R));
    d(d == 0) = 1;

    Q = Q * diag(d);
end


function Y = rowNormalize(X)
    rowNorm = sqrt(sum(X.^2, 2));
    rowNorm(rowNorm < eps) = 1;
    Y = X ./ rowNorm;
end


function X = zscoreSafe(X)

    mu = mean(X, 1);
    sigma = std(X, 0, 1);

    sigma(sigma < eps) = 1;

    X = (X - mu) ./ sigma;
end

%% ========================================================================
%                            聚类评价指标
% ========================================================================

function metrics = clusteringMetrics(gnd, pred)

    gnd = gnd(:);
    pred = pred(:);

    [~, ~, gndId] = unique(gnd);
    [~, ~, predId] = unique(pred);

    numPred = max(predId);
    numTrue = max(gndId);

    Cont = accumarray([predId, gndId], 1, [numPred, numTrue]);

    metrics.ACC = clusteringACC(Cont);
    metrics.NMI = clusteringNMI(Cont);
    metrics.ARI = clusteringARI(Cont);
    metrics.Purity = clusteringPurity(Cont);
end


function acc = clusteringACC(Cont)

    K = max(size(Cont));
    W = zeros(K, K);
    W(1:size(Cont, 1), 1:size(Cont, 2)) = Cont;

    if exist('matchpairs', 'file') == 2
        cost = max(W(:)) - W;
        pairs = matchpairs(cost, max(cost(:)) + 1);

        val = 0;
        for i = 1:size(pairs, 1)
            val = val + W(pairs(i, 1), pairs(i, 2));
        end
    else
        warning('matchpairs not found. Using greedy assignment fallback.');
        val = greedyAssignment(W);
    end

    acc = val / sum(W(:));
end


function val = greedyAssignment(W)

    val = 0;
    Wtmp = W;

    while true
        [m, ind] = max(Wtmp(:));

        if m <= 0
            break;
        end

        [i, j] = ind2sub(size(Wtmp), ind);

        val = val + Wtmp(i, j);

        Wtmp(i, :) = -inf;
        Wtmp(:, j) = -inf;
    end
end


function nmi = clusteringNMI(Cont)

    N = sum(Cont(:));

    Pi = sum(Cont, 2);
    Pj = sum(Cont, 1);

    MI = 0;

    for i = 1:size(Cont, 1)
        for j = 1:size(Cont, 2)
            if Cont(i, j) > 0
                MI = MI + Cont(i, j) / N * ...
                    log((Cont(i, j) * N) / (Pi(i) * Pj(j)));
            end
        end
    end

    Hi = -sum((Pi(Pi > 0) / N) .* log(Pi(Pi > 0) / N));
    Hj = -sum((Pj(Pj > 0) / N) .* log(Pj(Pj > 0) / N));

    nmi = 2 * MI / (Hi + Hj + eps);
end


function ari = clusteringARI(Cont)

    comb2 = @(x) x .* (x - 1) / 2;

    N = sum(Cont(:));

    sumNij = sum(comb2(Cont(:)));
    sumAi = sum(comb2(sum(Cont, 2)));
    sumBj = sum(comb2(sum(Cont, 1)));

    total = comb2(N);

    expectedIndex = sumAi * sumBj / total;
    maxIndex = 0.5 * (sumAi + sumBj);

    ari = (sumNij - expectedIndex) / (maxIndex - expectedIndex + eps);
end


function purity = clusteringPurity(Cont)
    purity = sum(max(Cont, [], 2)) / sum(Cont(:));
end
